def square_root(num1):
    num1 = float(num1)
    solution = num1 ** 0.5
    return solution
