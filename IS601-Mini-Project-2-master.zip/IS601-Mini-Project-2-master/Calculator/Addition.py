def addition(num1, num2):
    num1 = float(num1)
    num2 = float(num2)
    solution = num1 + num2
    return solution
