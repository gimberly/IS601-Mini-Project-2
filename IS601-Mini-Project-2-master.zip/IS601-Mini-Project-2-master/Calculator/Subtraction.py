def subtraction(num1, num2):
    num1 = float(num1)
    num2 = float(num2)
    solution = num2 - num1
    return solution
