def square(num1):
    num1 = float(num1)
    solution = num1 ** 2
    return solution
