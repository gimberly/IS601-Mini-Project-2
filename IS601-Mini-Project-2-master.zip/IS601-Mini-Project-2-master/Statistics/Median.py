import statistics


def median(median_list):
    solution = statistics.median(median_list)
    return solution
