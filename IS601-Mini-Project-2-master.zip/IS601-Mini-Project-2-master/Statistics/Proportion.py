from Calculator.Addition import addition
from Calculator.Division import division
from Statistics.Num_Values import num_values


def proportion(proportion_list):
    return division(proportion_list, num_values)
