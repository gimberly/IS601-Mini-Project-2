import statistics


def mode(mode_list):
    solution = statistics.mode(mode_list)
    return solution
