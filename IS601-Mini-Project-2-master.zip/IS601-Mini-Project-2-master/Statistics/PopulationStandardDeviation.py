import statistics


def population_standard_deviance(pop_standard_deviation_list):
    solution = statistics.pstdev(pop_standard_deviation_list)
    return solution