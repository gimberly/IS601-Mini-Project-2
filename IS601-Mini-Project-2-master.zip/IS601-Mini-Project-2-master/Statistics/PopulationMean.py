import statistics


def population_mean(mean_list):
    solution = (statistics.mean(mean_list))
    return solution
